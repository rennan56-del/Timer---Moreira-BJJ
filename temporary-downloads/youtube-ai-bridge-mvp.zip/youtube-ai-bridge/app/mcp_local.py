"""Local MCP stdio server for Codex/other compatible desktop coding agents.
Not exposed on the public network. Do not send sensitive OAuth cookies here.
"""
from mcp.server.fastmcp import FastMCP
from app import core

mcp = FastMCP("YouTube AI Bridge - local")


@mcp.tool()
def search_youtube(query: str, limit: int = 10) -> list[dict]:
    """Search public YouTube videos (no paid API)."""
    return core.search_youtube(query, limit)


@mcp.tool()
def get_video_info(url_or_id: str) -> dict:
    """Get title, duration, views, date and other public video metadata."""
    return core.get_video_info(url_or_id)


@mcp.tool()
def get_video_transcript(url_or_id: str, language: str = "pt", translate_to: str = "") -> dict:
    """Get a full transcript into cache, with ALL timestamped segments and provenance. No fabricated text."""
    data = core.fetch_transcript(url_or_id, language, translate_to)
    return {k: v for k, v in data.items() if k != "segments"} | {"instruction": "Call get_transcript_chunk(start=0) repeatedly until has_more=false to read the complete text."}


@mcp.tool()
def get_transcript_chunk(url_or_id: str, start: int = 0, count: int = 120, language: str = "") -> dict:
    """Read timestamped transcript in chunks. Read all chunks before claiming a detailed review."""
    return core.get_chunk(url_or_id, start, count, language or None)


@mcp.tool()
def list_saved_transcripts(limit: int = 30) -> list[dict]:
    """List locally cached transcripts; no YouTube call or API charge."""
    return core.list_saved(limit)


if __name__ == "__main__":
    mcp.run(transport="stdio")
