"""Password-protected web interface and REST API for the personal bridge."""
import hmac
import json
import os
from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException, Query
from fastapi.responses import HTMLResponse, PlainTextResponse, JSONResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from pydantic import BaseModel

from app import core

app = FastAPI(title="YouTube AI Bridge", version="0.1.0", docs_url="/docs", redoc_url=None)
security = HTTPBasic()
LOGIN_USER = os.getenv("BRIDGE_USER", "")
LOGIN_PASS = os.getenv("BRIDGE_PASSWORD", "")
if not LOGIN_USER or not LOGIN_PASS or LOGIN_PASS == "CHANGE_ME":
    raise RuntimeError("Defina BRIDGE_USER e BRIDGE_PASSWORD fortes no .env")


def auth(credentials: HTTPBasicCredentials = Depends(security)):
    ok_user = hmac.compare_digest(credentials.username.encode(), LOGIN_USER.encode())
    ok_pass = hmac.compare_digest(credentials.password.encode(), LOGIN_PASS.encode())
    if not (ok_user and ok_pass):
        raise HTTPException(status_code=401, detail="Credenciais incorretas", headers={"WWW-Authenticate": "Basic"})
    return credentials.username


class FetchBody(BaseModel):
    url: str
    prefer_language: str = "pt"
    translate_to: str = ""
    refresh: bool = False


def wrap_errors(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except core.BridgeError as exc:
        raise HTTPException(422, str(exc)) from exc


@app.get("/", response_class=HTMLResponse, dependencies=[Depends(auth)])
def home():
    return Path(__file__).with_name("index.html").read_text(encoding="utf-8")


@app.get("/api/search", dependencies=[Depends(auth)])
def search(q: str = Query(min_length=2, max_length=180), limit: int = Query(10, ge=1, le=20)):
    return {"results": wrap_errors(core.search_youtube, q, limit)}


@app.get("/api/video", dependencies=[Depends(auth)])
def video_info(url: str):
    return wrap_errors(core.get_video_info, url)


@app.post("/api/transcripts", dependencies=[Depends(auth)])
def transcript(body: FetchBody):
    return wrap_errors(core.fetch_transcript, body.url, body.prefer_language, body.translate_to, body.refresh)


@app.get("/api/history", dependencies=[Depends(auth)])
def history():
    return {"results": core.list_saved()}


@app.get("/api/transcripts/{video_id}", dependencies=[Depends(auth)])
def saved(video_id: str, language: str = ""):
    vid = wrap_errors(core.video_id_from, video_id)
    value = core.load_saved(vid, language or None)
    if value is None:
        raise HTTPException(404, "Transcrição não está em cache")
    return value


@app.get("/api/transcripts/{video_id}/chunk", dependencies=[Depends(auth)])
def chunk(video_id: str, start: int = 0, count: int = 120, language: str = ""):
    return wrap_errors(core.get_chunk, video_id, start, count, language or None)


@app.get("/api/transcripts/{video_id}/export", dependencies=[Depends(auth)])
def export(video_id: str, fmt: str = "txt", language: str = ""):
    vid = wrap_errors(core.video_id_from, video_id)
    data = core.load_saved(vid, language or None)
    if data is None:
        raise HTTPException(404, "Transcrição não está em cache")
    if fmt == "txt":
        response = PlainTextResponse(core.as_text(data["segments"]))
        ext = "txt"
    elif fmt == "srt":
        response = PlainTextResponse(core.as_srt(data["segments"]))
        ext = "srt"
    elif fmt == "json":
        response = JSONResponse(data)
        ext = "json"
    else:
        raise HTTPException(422, "Formato precisa ser txt, srt ou json")
    response.headers["Content-Disposition"] = f'attachment; filename="{vid}-{data["language"]}.{ext}"'
    return response
