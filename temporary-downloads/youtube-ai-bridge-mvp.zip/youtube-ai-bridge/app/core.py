"""Shared non-AI YouTube search, transcript retrieval, and cache."""
from __future__ import annotations

import json
import os
import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import parse_qs, urlparse

DB_FILE = Path(os.getenv("DB_PATH", "/data/bridge.sqlite3"))
MAX_TRANSCRIPT_CHARS = 600_000
ID_RE = re.compile(r"^[A-Za-z0-9_-]{11}$")


class BridgeError(ValueError):
    pass


def video_id_from(value: str) -> str:
    value = value.strip()
    if ID_RE.fullmatch(value):
        return value
    try:
        url = urlparse(value)
    except ValueError:
        raise BridgeError("URL inválida")
    host = (url.hostname or "").lower()
    if url.scheme not in ("https", "http"):
        raise BridgeError("Use um link HTTPS do YouTube")
    if host in ("youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com"):
        if url.path == "/watch":
            candidate = parse_qs(url.query).get("v", [""])[0]
        elif url.path.startswith(("/shorts/", "/live/", "/embed/")):
            candidate = url.path.split("/")[2]
        else:
            candidate = ""
    elif host == "youtu.be":
        candidate = url.path.lstrip("/").split("/")[0]
    else:
        raise BridgeError("Somente URLs oficiais do YouTube")
    if not ID_RE.fullmatch(candidate):
        raise BridgeError("Identificador do vídeo inválido")
    return candidate


def connection():
    DB_FILE.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(DB_FILE), timeout=20)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("""CREATE TABLE IF NOT EXISTS transcripts (
      video_id TEXT NOT NULL, language TEXT NOT NULL, title TEXT NOT NULL,
      is_generated INTEGER NOT NULL, source_language TEXT NOT NULL,
      segments TEXT NOT NULL, saved_at TEXT NOT NULL,
      PRIMARY KEY(video_id, language))""")
    return con


def fmt_time(value: float) -> str:
    sec = max(0, int(value))
    hours, rest = divmod(sec, 3600)
    mins, secs = divmod(rest, 60)
    return f"{hours:02d}:{mins:02d}:{secs:02d}"


def fmt_srt(value: float) -> str:
    ms = max(0, int(round(value * 1000)))
    hours, rest = divmod(ms, 3_600_000)
    mins, rest = divmod(rest, 60_000)
    secs, milli = divmod(rest, 1000)
    return f"{hours:02d}:{mins:02d}:{secs:02d},{milli:03d}"


def as_text(segments):
    return "\n".join(f"[{fmt_time(float(s['start']))}] {s['text']}" for s in segments)


def as_srt(segments):
    return "\n\n".join(
        f"{i}\n{fmt_srt(float(s['start']))} --> {fmt_srt(float(s['start']) + float(s['duration']))}\n{s['text']}"
        for i, s in enumerate(segments, 1)
    ) + "\n"


def search_youtube(query: str, limit: int = 10):
    from yt_dlp import YoutubeDL
    query = query.strip()
    if len(query) < 2 or len(query) > 180:
        raise BridgeError("Pesquisa precisa de 2 a 180 caracteres")
    limit = min(max(int(limit), 1), 20)
    opts = {"extract_flat": "in_playlist", "skip_download": True, "quiet": True,
            "no_warnings": True, "socket_timeout": 20, "ignoreerrors": True,
            "noplaylist": True, "cachedir": False}
    try:
        with YoutubeDL(opts) as ydl:
            result = ydl.extract_info(f"ytsearch{limit}:{query}", download=False)
    except Exception as exc:
        raise BridgeError(f"Não foi possível pesquisar no YouTube: {type(exc).__name__}") from exc
    videos = []
    for entry in (result or {}).get("entries", []):
        if not entry:
            continue
        vid = entry.get("id") or ""
        if not ID_RE.fullmatch(vid):
            continue
        videos.append({"id": vid, "title": entry.get("title") or "Título indisponível",
                       "channel": entry.get("channel") or entry.get("uploader") or "Canal não identificado",
                       "duration": entry.get("duration"), "view_count": entry.get("view_count"),
                       "url": f"https://www.youtube.com/watch?v={vid}"})
    return videos


def load_saved(vid: str, lang: str | None = None):
    con = connection()
    try:
        if lang:
            r = con.execute("SELECT * FROM transcripts WHERE video_id=? AND language=?", (vid, lang)).fetchone()
        else:
            r = con.execute("SELECT * FROM transcripts WHERE video_id=? ORDER BY saved_at DESC LIMIT 1", (vid,)).fetchone()
    finally:
        con.close()
    if not r:
        return None
    obj = dict(r)
    obj["segments"] = json.loads(obj["segments"])
    obj["is_generated"] = bool(obj["is_generated"])
    obj["total_segments"] = len(obj["segments"])
    obj["status"] = "complete"
    obj["translated"] = obj["source_language"] != obj["language"]
    obj["url"] = f"https://www.youtube.com/watch?v={vid}"
    return obj


def save_transcript(data):
    con = connection()
    try:
        con.execute("""INSERT OR REPLACE INTO transcripts
        (video_id,language,title,is_generated,source_language,segments,saved_at)
        VALUES(?,?,?,?,?,?,?)""",
        (data["video_id"], data["language"], data["title"],
         int(data["is_generated"]), data["source_language"],
         json.dumps(data["segments"], ensure_ascii=False),
         datetime.now(timezone.utc).isoformat()))
        con.commit()
    finally:
        con.close()


def fetch_transcript(value: str, prefer_language: str = "pt", translate_to: str = "", refresh: bool = False):
    from youtube_transcript_api import YouTubeTranscriptApi
    vid = video_id_from(value)
    prefer_language = prefer_language.lower().strip()
    translate_to = translate_to.lower().strip()
    if not re.fullmatch(r"[a-z]{2,3}(?:-[a-z]{2,3})?", prefer_language):
        raise BridgeError("Idioma inválido")
    if translate_to and not re.fullmatch(r"[a-z]{2,3}(?:-[a-z]{2,3})?", translate_to):
        raise BridgeError("Idioma de tradução inválido")
    desired = translate_to or prefer_language
    if not refresh:
        saved = load_saved(vid, desired) or (load_saved(vid) if not translate_to else None)
        if saved:
            return saved
    try:
        tracks = list(YouTubeTranscriptApi().list(vid))
        if not tracks:
            raise BridgeError("O vídeo não tem transcrições disponíveis")
        # Prefer source language; fallback to English or first available track.
        preferred_codes = (prefer_language, "pt", "en")
        track = next((t for lang in preferred_codes for t in tracks if t.language_code.lower() == lang), tracks[0])
        source_language = track.language_code
        translated = False
        if translate_to and source_language != translate_to:
            if not track.is_translatable:
                raise BridgeError(f"O YouTube não disponibiliza tradução de {source_language} para {translate_to}")
            supported = {lang["language_code"] for lang in track.translation_languages}
            if translate_to not in supported:
                raise BridgeError(f"Tradução para {translate_to} indisponível neste vídeo")
            track = track.translate(translate_to)
            translated = True
        fetched = track.fetch()
        segments = [{"start": float(x.start), "duration": float(x.duration),
                     "text": x.text.strip()} for x in fetched if x.text and x.text.strip()]
        if not segments:
            raise BridgeError("A transcrição retornou vazia")
        if sum(len(x["text"]) for x in segments) > MAX_TRANSCRIPT_CHARS:
            raise BridgeError("Transcrição excede limite de tamanho; não foi truncada")
    except BridgeError:
        raise
    except Exception as exc:
        # Explicitly distinguish blocked/unavailable from successful extraction.
        raise BridgeError(f"Transcrição indisponível ({type(exc).__name__}). O YouTube pode ter bloqueado o IP da VPS ou desativado legendas.") from exc
    title = "Título não recuperado"
    # Metadata failure should not prevent successful caption extraction.
    try:
        from yt_dlp import YoutubeDL
        with YoutubeDL({"quiet": True, "skip_download": True, "no_warnings": True,
                        "socket_timeout": 12, "cachedir": False}) as ydl:
            info = ydl.extract_info(f"https://www.youtube.com/watch?v={vid}", download=False)
        title = (info or {}).get("title") or title
    except Exception:
        pass
    data = {"video_id": vid, "url": f"https://www.youtube.com/watch?v={vid}",
            "title": title, "language": getattr(fetched, "language_code", desired),
            "source_language": source_language, "translated": translated,
            "is_generated": bool(getattr(fetched, "is_generated", False)),
            "segments": segments, "total_segments": len(segments), "status": "complete"}
    save_transcript(data)
    return data


def get_chunk(value: str, start: int = 0, count: int = 120, lang: str | None = None):
    vid = video_id_from(value)
    transcript = load_saved(vid, lang)
    if transcript is None:
        raise BridgeError("Vídeo não está em cache; extraia primeiro")
    total = len(transcript["segments"])
    if start < 0 or count < 1 or count > 500:
        raise BridgeError("Intervalo inválido")
    end = min(start + count, total)
    return {"video_id": vid, "language": transcript["language"],
            "title": transcript["title"], "start": start, "end": end,
            "total": total, "has_more": end < total,
            "text": as_text(transcript["segments"][start:end]),
            "segments": transcript["segments"][start:end]}


def list_saved(limit: int = 50):
    con = connection()
    try:
        rows = con.execute("""SELECT video_id,language,title,source_language,saved_at,
            LENGTH(segments) as json_bytes FROM transcripts ORDER BY saved_at DESC LIMIT ?""",
                           (min(max(int(limit), 1), 100),)).fetchall()
        return [dict(r) for r in rows]
    finally:
        con.close()
