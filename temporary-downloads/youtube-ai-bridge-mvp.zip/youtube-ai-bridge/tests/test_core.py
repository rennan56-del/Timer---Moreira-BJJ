import os
from pathlib import Path
import tempfile
import unittest

from app import core


class CoreTests(unittest.TestCase):
    def test_ids(self):
        valid = ["w3SgBRIefTQ", "https://www.youtube.com/watch?v=w3SgBRIefTQ&t=2s",
                 "https://youtu.be/w3SgBRIefTQ", "https://www.youtube.com/shorts/w3SgBRIefTQ"]
        for value in valid:
            self.assertEqual(core.video_id_from(value), "w3SgBRIefTQ")
        for bad in ("https://evil.com/watch?v=w3SgBRIefTQ", "https://youtube.com.evil.org/watch?v=w3SgBRIefTQ",
                    "https://127.0.0.1/test", "../../secret", "https://www.youtube.com/watch?v=no"):
            with self.assertRaises(core.BridgeError):
                core.video_id_from(bad)

    def test_timestamps(self):
        self.assertEqual(core.fmt_time(3661.95), "01:01:01")
        self.assertEqual(core.fmt_srt(61.250), "00:01:01,250")

    def test_cache_and_chunks(self):
        with tempfile.TemporaryDirectory() as tmp:
            old = core.DB_FILE
            core.DB_FILE = Path(tmp) / 'db.sqlite3'
            try:
                core.save_transcript({"video_id":"w3SgBRIefTQ", "title":"Vídeo teste", "language":"en",
                                      "source_language":"en", "is_generated":True,
                                      "segments":[{"start":0, "duration":1.5,"text":"Olá"},
                                                  {"start":1.5,"duration":3,"text":"mundo"}]})
                saved = core.load_saved('w3SgBRIefTQ', 'en')
                self.assertEqual(saved['status'], 'complete')
                result = core.get_chunk('w3SgBRIefTQ',0,1,'en')
                self.assertTrue(result['has_more'])
                self.assertEqual(result['end'],1)
                self.assertIn('Olá',result['text'])
                self.assertIn('00:00:01,500',core.as_srt(saved['segments']))
            finally:
                core.DB_FILE = old

if __name__ == '__main__': unittest.main()
