# YouTube AI Bridge — MVP pessoal

Aplicativo self-hosted para pesquisar vídeos públicos no YouTube, recuperar legendas disponíveis **sem API paga**, manter cache em SQLite, exportar TXT/SRT/JSON e acessar transcrições por ferramentas MCP **locais** (Codex e clientes compatíveis). O próprio YouTube pode bloquear IPs de VPS ou indisponibilizar legendas; nesse caso o aplicativo informa a falha sem fabricar texto.

## O que já vem implementado

- Busca via `yt-dlp` (retorna resultados que o YouTube permitir); URL direta também é aceita.
- Legendas manuais/automáticas via `youtube-transcript-api`; preferência de idioma, tradução do YouTube *quando oferecida* e timestamps.
- Histórico SQLite, visualização completa, download TXT/SRT/JSON, API REST e MCP local para agentes.
- Autenticação HTTP Basic na interface/API, porta vinculada **somente ao localhost** da VPS, sem Tailscale nem API da OpenAI.
- Ferramentas MCP: `search_youtube`, `get_video_info`, `get_video_transcript`, `get_transcript_chunk`, `list_saved_transcripts`.

## Instalar na VPS (por Codex/Antigravity com acesso SSH)

Não execute sobre diretórios de aplicações existentes. Crie um novo diretório, por exemplo `/opt/youtube-ai-bridge`:

```bash
cd /opt/youtube-ai-bridge
cp .env.example .env
# Edite o .env e defina BRIDGE_USER e BRIDGE_PASSWORD com credenciais únicas e fortes.
chmod 600 .env
docker compose up -d --build
docker compose ps
curl -I http://127.0.0.1:8787/   # esperado: 401 sem credenciais
curl -u 'seu_usuario:SUA_SENHA' http://127.0.0.1:8787/api/history
```

Acesse via túnel SSH local (por exemplo `ssh -L 8787:127.0.0.1:8787 usuario@vps` e `http://localhost:8787`), ou configure no proxy HTTPS **já existente na VPS** um hostname com acesso autenticado restrito. Nunca publique a porta 8787 diretamente na internet. Em HTTPS as credenciais do Basic não trafegam em claro. O aplicativo não configura domínio/HTTPS automaticamente.

## Uso com Codex via MCP local

O container já em execução pode hospedar um MCP por stdio, sem expor endpoint remoto. Um cliente MCP local na VPS deve iniciar este comando:

```bash
docker exec -i youtube-ai-bridge python -m app.mcp_local
```

Exemplo de seção de configuração TOML para um cliente que aceite MCP por stdio (ajuste aos comandos/sintaxe do cliente instalado):

```toml
[mcp_servers.youtube_ai_bridge]
command = "docker"
args = ["exec", "-i", "youtube-ai-bridge", "python", "-m", "app.mcp_local"]
```

Isso funciona **apenas com clientes que consigam executar o comando no mesmo servidor Docker**. Não instala um plugin dentro deste chat. Para ChatGPT remoto pode ser necessário um conector MCP remoto com HTTPS e OAuth, dependendo das permissões da conta. Não exponha este servidor stdio ou endpoints sem autenticação. Não há módulo remoto MCP nesta versão inicial.

## Como ler um vídeo grande sem omissões

A ferramenta MCP `get_video_transcript` guarda a transcrição e retorna um recibo com metadados, sem despejar dezenas de milhares de tokens de uma vez. Depois chame `get_transcript_chunk(start=0, count=120)` e continue passando `start=end` até `has_more=false`. Assim o agente pode ler **todos** os blocos em sequência. Jamais afirmar que leu integralmente se nem todos os blocos foram recuperados.

## Testes

```bash
python -m unittest discover -s tests -v
# Os testes unitários não exigem conexão ao YouTube.
# Para teste real, abra a aplicação e forneça uma URL pública que tenha legendas.
```

**Limitações:** Não foi testado em uma VPS real nesta entrega; os testes locais cobrem validação de URLs, tempos, exportação e cache. O YouTube pode recusar solicitações feitas de IPs de hospedagem. Caso não existam legendas acessíveis, o MVP informa o problema; transcrição de áudio enviado pelo usuário é uma extensão futura. Visualizações podem estar indisponíveis na pesquisa. A tradução depende das opções oferecidas pelo YouTube.

## YouTube Premium

Premium permite benefícios de reprodução na conta, mas **não concede uma API de transcrições para vídeos de terceiros nem significa acesso automático às legendas pela VPS**. Este aplicativo não pede suas senhas, cookies, sessão do Google ou uma chave de API do ChatGPT.

## Segurança

Por padrão a API só é acessível no próprio host. Credenciais são enviadas pelo navegador via HTTP Basic (use sempre HTTPS no acesso remoto). Antes de conectar o MCP ao ChatGPT pela internet, implemente OAuth, limites de requisição, registros e revisões de segurança. O software trabalha apenas com vídeos públicos e transcrições disponibilizadas, sem burlar controles de acesso.
